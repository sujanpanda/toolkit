import './App.css';
import Profile from './components/Profile';

function App() {
  return (
    <div className="App">
      <h1>Redux Toolkit</h1>
      <Profile />
    </div>
  );
}

export default App;
